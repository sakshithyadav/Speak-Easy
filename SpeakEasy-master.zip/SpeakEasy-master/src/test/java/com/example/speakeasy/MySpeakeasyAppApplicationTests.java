package com.example.speakeasy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpeakeasyAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
